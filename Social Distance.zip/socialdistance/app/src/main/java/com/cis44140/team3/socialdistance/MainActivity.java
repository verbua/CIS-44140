package com.cis44140.team3.socialdistance;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private RecyclerView postList;
    private Toolbar mToolbar;
    private AppBarConfiguration mAppBarConfiguration;

    private CircleImageView navProfileImage, reallySmallProfileImage;
    private TextView nav_profile_username;
    private TextView nav_profile_fullName;
    private TextView nav_profile_email;

    FloatingActionButton fab, fab1, fab2;
    Animation fabOpen, fabClose;
    boolean isOpen=false;

    String current_user_id;
    boolean likeChecker = false;

    private FirebaseAuth mAuth;
    private DatabaseReference UsersRef;
    private DatabaseReference PostsRef;
    private DatabaseReference likesRef;
    private Query postsQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fab = (FloatingActionButton) findViewById(R.id.addFab);
        fab1 = (FloatingActionButton) findViewById(R.id.photoPostFab);
        fab2 = (FloatingActionButton) findViewById(R.id.textPostFab);

        fabOpen = AnimationUtils.loadAnimation(this, R.anim.fab_open);
        fabClose = AnimationUtils.loadAnimation(this, R.anim.fab_close);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animateFab();
            }
        });

        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animateFab();
            }
        });
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                animateFab();
                Toast.makeText(MainActivity.this, "Text Post to be created", Toast.LENGTH_SHORT).show();
            }
        });

        mAuth = FirebaseAuth.getInstance();
        current_user_id = Objects.requireNonNull(mAuth.getCurrentUser()).getUid();
        UsersRef = FirebaseDatabase.getInstance().getReference().child("Users");
        PostsRef = FirebaseDatabase.getInstance().getReference().child("Posts");
        postsQuery = FirebaseDatabase.getInstance().getReference().child("Posts").orderByChild("fullTimeStamp");
        likesRef = FirebaseDatabase.getInstance().getReference().child("Likes");

        reallySmallProfileImage = (CircleImageView) findViewById(R.id.top_bar_profile_image);

        mToolbar = (Toolbar) findViewById(R.id.main_page_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setHomeButtonEnabled(true);


        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        actionBarDrawerToggle = new ActionBarDrawerToggle(MainActivity.this, drawerLayout, R.string.drawer_open, R.string.drawer_close);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        actionBarDrawerToggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.navigation_view);

        postList = (RecyclerView) findViewById(R.id.all_users_post_list);
        postList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        postList.setLayoutManager(linearLayoutManager);

        View navView = navigationView.inflateHeaderView(R.layout.navigation_header);

        UsersRef.child(mAuth.getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {

                    navProfileImage = (CircleImageView) findViewById(R.id.nav_profile_image);
                    nav_profile_username = (TextView) findViewById(R.id.nav_header_username);
                    nav_profile_fullName = (TextView) findViewById(R.id.nav_header_fullname);
                    nav_profile_email = (TextView) findViewById(R.id.nav_profile_email);

                    if (dataSnapshot.hasChild("fullname")) {
                        final String fullName = Objects.requireNonNull(dataSnapshot.child("fullname").getValue()).toString();
                        nav_profile_fullName.setText(fullName);
                    }
                    if (dataSnapshot.hasChild("profileimage")) {
                        final String image = Objects.requireNonNull(dataSnapshot.child("profileimage").getValue()).toString();
                        Picasso.get().load(image).placeholder(R.drawable.profile).into(navProfileImage);
                        Picasso.get().load(image).placeholder(R.drawable.profile).into(reallySmallProfileImage);
                    }
                    if (dataSnapshot.hasChild("username")) {
                        final String username = Objects.requireNonNull(dataSnapshot.child("username").getValue()).toString();
                        nav_profile_username.setText(username);
                    }
                    if (dataSnapshot.hasChild("email")) {
                        final String email = Objects.requireNonNull(dataSnapshot.child("email").getValue()).toString();
                        nav_profile_email.setText(email);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                UserMenuSelector(menuItem);

                return false;
            }
        });

        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SendUserToPostPhoto();
            }
        });

        DisplayAllUsersPosts();

        reallySmallProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(Gravity.LEFT);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser == null) {
            SendUserToLoginActivity();
        } else {
            checkUserExistence();
        }
    }

    public static class postViewHolder extends RecyclerView.ViewHolder {

        TextView fullname, date, time, photoDescription, actualUsername, likeCounterTextView, commentsCounterTextView, viewsCounterTextView;
        ImageView postImage, likesImageView, commentsCountImageView;
        CircleImageView profileImage;
        int numberOfLikes, numberOfComments, numberOfViews;
        String current_user_id;
        DatabaseReference LikesRef, CommentsRef, viewsRef;

        public postViewHolder(@NonNull View itemView) {
            super(itemView);
            current_user_id = FirebaseAuth.getInstance().getCurrentUser().getUid();
            LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");

            actualUsername = itemView.findViewById(R.id.post_actual_username);
            fullname = itemView.findViewById(R.id.post_full_name);
            date = itemView.findViewById(R.id.post_date);
            time = itemView.findViewById(R.id.post_time);
            postImage = itemView.findViewById(R.id.post_image);
            profileImage = itemView.findViewById(R.id.post_profile_image);
            photoDescription = itemView.findViewById(R.id.post_description);
            likesImageView = (ImageView) itemView.findViewById(R.id.likesImageView);
            commentsCountImageView = (ImageView) itemView.findViewById(R.id.commentsCountImageView);

            likeCounterTextView = (TextView) itemView.findViewById(R.id.likeCounterTextView);
            commentsCounterTextView = (TextView) itemView.findViewById(R.id.commentsCountTextView);
            viewsCounterTextView = (TextView) itemView.findViewById(R.id.watcherCounterTextView);

        }

        public void setLikeButtonStatus(final String postKey) {
            LikesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child(postKey).hasChild(current_user_id)) {
                        numberOfLikes = (int) dataSnapshot.child(postKey).getChildrenCount();
                        likesImageView.setImageResource(R.drawable.ic_thumb_up_red);
                        likeCounterTextView.setText(Integer.toString(numberOfLikes));
                    } else {
                        numberOfLikes = (int) dataSnapshot.child(postKey).getChildrenCount();
                        likesImageView.setImageResource(R.drawable.ic_thumb_up);
                        likeCounterTextView.setText(Integer.toString(numberOfLikes));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        public void setCommentButtonStatus(final String postKey) {
            CommentsRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(postKey).child("comments");
            CommentsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        numberOfComments = (int) dataSnapshot.getChildrenCount();
                        commentsCounterTextView.setText(Integer.toString(numberOfComments));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        public void setViewsButtonStatus(String postKey) {
            viewsRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(postKey).child("views");
            viewsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        numberOfViews = (int) Integer.valueOf(dataSnapshot.getValue().toString());
                        viewsCounterTextView.setText(Integer.toString(numberOfViews));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }

    private void DisplayAllUsersPosts() {
        FirebaseRecyclerOptions<post> postOptions = new FirebaseRecyclerOptions.Builder<post> ()
                .setQuery(postsQuery, post.class).build();

        FirebaseRecyclerAdapter<post, postViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<post, postViewHolder>(postOptions) {
                    @Override
                    protected void onBindViewHolder(@NonNull postViewHolder holder, int position, @NonNull post model) {

                        final String postKey = getRef(position).getKey();
                        final int views = model.getViews() + 1;

                        holder.fullname.setText(model.getFullname());
                        Picasso.get().load(model.getPostimage()).into(holder.postImage);
                        Picasso.get().load(model.getProfileimage()).into(holder.profileImage);
                        holder.date.setText(model.getDate());
                        holder.time.setText(model.getTime());
                        holder.photoDescription.setText(model.getDescription());
                        holder.actualUsername.setText(model.getUsername());

                        holder.setLikeButtonStatus(postKey);
                        holder.setCommentButtonStatus(postKey);
                        holder.setViewsButtonStatus(postKey);

                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                PostsRef.child(postKey).child("views").setValue(views);

                                Intent clickPostIntent = new Intent(MainActivity.this, ClickPostActivity.class);
                                clickPostIntent.putExtra("postKey", postKey);
                                startActivity(clickPostIntent);
                            }
                        });

                        holder.likesImageView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                likeChecker = true;
                                likesRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if (likeChecker) {
                                            if (dataSnapshot.child(postKey).hasChild(current_user_id)) {
                                                likesRef.child(postKey).child(current_user_id).removeValue();
                                                likeChecker = false;
                                            } else {
                                                likesRef.child(postKey).child(current_user_id).setValue(true);
                                                likeChecker = false;
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }
                        });

                        holder.commentsCountImageView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent clickPostIntent = new Intent(MainActivity.this, ClickPostActivity.class);
                                clickPostIntent.putExtra("postKey", postKey);
                                startActivity(clickPostIntent);
                            }
                        });

                    }

                    @NonNull
                    @Override
                    public postViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.all_post_layout, parent, false);
                        postViewHolder viewHolder = new postViewHolder(view);
                        return viewHolder;
                    }
                };

        postList.setAdapter(firebaseRecyclerAdapter);
        firebaseRecyclerAdapter.startListening();
    }

    private void SendUserToPostPhoto() {
        Intent postIntent = new Intent(MainActivity.this, PostActivity.class);
        startActivity(postIntent);
    }

    private void checkUserExistence() {
        final String current_user_id = mAuth.getCurrentUser().getUid();
        UsersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (!dataSnapshot.hasChild(current_user_id)) {
                    SendUserToSetupActivity();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void SendUserToSetupActivity() {
        Intent setupIntent = new Intent(MainActivity.this, SetupActivity.class);
        startActivity(setupIntent);
        finish();
    }

    private void SendUserToLoginActivity() {
        Intent loginIntent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(loginIntent);
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.top_bar_messages_icon:
                break;
            case R.id.top_bar_search_search_icon:
                SendUserToSearchActivity();
                break;
        }

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void SendUserToSearchActivity() {
        Intent searchIntent = new Intent(MainActivity.this, FindFriendsActivity.class);
        startActivity(searchIntent);
    }

    private void UserMenuSelector(MenuItem item){

        switch (item.getItemId()) {
            case R.id.nav_profile:
                SendUserToProfileActivity();
                break;
            case R.id.nav_home:
                SendUserToHome();
                break;
            case R.id.nav_friends:
                Toast.makeText(MainActivity.this, "Friends Clicked", Toast.LENGTH_SHORT).show();
                break;
            case R.id.nav_find_friends:
                SendUserToSearchActivity();
                break;
            case R.id.nav_settings:
                SendUserToSettingsActivity();
                break;
            case R.id.nav_logout:
                mAuth.signOut();
                SendUserToLoginActivity();
                break;
        }

    }

    private void SendUserToProfileActivity() {
        Intent profileIntent = new Intent(MainActivity.this, ProfileActivity.class);
        startActivity(profileIntent);
    }

    private void SendUserToSettingsActivity() {
        Intent settingIntent = new Intent(MainActivity.this, SettingsActivity.class);
        startActivity(settingIntent);
    }

    private void SendUserToHome() {
        Intent mainIntent = new Intent(MainActivity.this, MainActivity.class);
        startActivity(mainIntent);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    private void animateFab() {

        if (isOpen) {
            fab1.startAnimation(fabClose);
            fab2.startAnimation(fabClose);
            fab1.setClickable(false);
            fab2.setClickable(false);
            isOpen=false;
        } else {
            fab1.startAnimation(fabOpen);
            fab2.startAnimation(fabOpen);
            fab1.setClickable(true);
            fab2.setClickable(true);
            isOpen=true;
        }

    }

}
