package com.cis44140.team3.socialdistance;

public class post {
    public String uid;
    public String time;
    public String date;
    public String postimage;
    public String description;
    public String profileimage;
    public String fullname;
    public String username;
    public String fullTimeStamp;
    public int views;

    public post() {

    }

    public post(String uid, String time, String date, String postimage, String description, String profileimage, String fullname, String actualUsername, String fullTimeStamp, int Views) {
        this.uid = uid;
        this.time = time;
        this.date = date;
        this.postimage = postimage;
        this.description = description;
        this.profileimage = profileimage;
        this.fullname = fullname;
        this.username = actualUsername;
        this.fullTimeStamp = fullTimeStamp;
        this.views = Views;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPostimage() {
        return postimage;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String uName) {
        this.username = uName;
    }

    public void setPostimage(String postimage) {
        this.postimage = postimage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProfileimage() {
        return profileimage;
    }

    public void setProfileimage(String profileimage) {
        this.profileimage = profileimage;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getfullTimeStamp() {
        return this.fullTimeStamp;
    }

    public void setfullTimeStamp(String fullTimeStamp) {
        this.fullTimeStamp = fullTimeStamp;
    }

    public int getViews() {
        return views;
    }

    public void setViews(int Views) {
        this.views = Views;
    }
}
