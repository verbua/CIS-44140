package com.cis44140.team3.socialdistance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class FriendsActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private RecyclerView friendList;
    private DatabaseReference friendsRef, usersRef;
    private FirebaseAuth mAuth;
    private String current_user_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);

        mAuth = FirebaseAuth.getInstance();
        current_user_id = mAuth.getCurrentUser().getUid();

        friendsRef = FirebaseDatabase.getInstance().getReference().child("Friends").child(current_user_id);
        usersRef = FirebaseDatabase.getInstance().getReference().child("Users");

        friendList = findViewById(R.id.friendsRecycler);

        mToolbar = (Toolbar) findViewById(R.id.friendsToolbar);
        setSupportActionBar(mToolbar);

        friendList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        friendList.setLayoutManager(linearLayoutManager);

        DisplayAllFriends();

    }

    private void DisplayAllFriends() {

        FirebaseRecyclerOptions<Friends> searchOptions = new FirebaseRecyclerOptions.Builder<Friends> ()
                .setQuery(friendsRef, Friends.class).build();

        FirebaseRecyclerAdapter<Friends, FriendsViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<Friends, FriendsViewHolder>(searchOptions) {
                    @Override
                    protected void onBindViewHolder(@NonNull final FriendsViewHolder holder, int position, @NonNull final Friends model) {

                        holder.setDate("Friends since: " + model.getDate());

                        final String userIds = getRef(position).getKey();

                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent profileIntent = new Intent(FriendsActivity.this, ViewProfileActivity.class);
                                profileIntent.putExtra("visit_user", userIds);
                                profileIntent.putExtra("previous_intent", "friends");
                                startActivity(profileIntent);
                            }
                        });

                        usersRef.child(userIds).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {
                                    final String username = dataSnapshot.child("username").getValue().toString();
                                    final String fullname = dataSnapshot.child("fullname").getValue().toString();
                                    if (dataSnapshot.hasChild("profileimage")) {
                                        final String profileImage = dataSnapshot.child("profileimage").getValue().toString();
                                        holder.setProfileImage(profileImage);
                                    }
                                    holder.setFullName(fullname);
                                    holder.setUserName(username);


                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                    }

                    @NonNull
                    @Override
                    public FriendsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.all_users_display_layout, parent, false);
                        FriendsViewHolder friendsViewHolder = new FriendsActivity.FriendsViewHolder(view);
                        return friendsViewHolder;
                    }
                };

        friendList.setAdapter(firebaseRecyclerAdapter);
        firebaseRecyclerAdapter.startListening();

    }

    public static class FriendsViewHolder extends RecyclerView.ViewHolder {

        CircleImageView profileImage;
        TextView userName, fullName, userStatus;

        public FriendsViewHolder(@NonNull View itemView) {
            super(itemView);

            profileImage = (CircleImageView) itemView.findViewById(R.id.all_user_profile_image);
            userName = (TextView) itemView.findViewById(R.id.all_user_username);
            fullName = (TextView) itemView.findViewById(R.id.all_user_full_name);
            userStatus = itemView.findViewById(R.id.all_user_user_status);
        }

        public void setUserName(String username) {
            userName.setText(username);
        }

        public void setFullName(String fullname) {
            fullName.setText(fullname);
        }

        public void setProfileImage(String profileimage) {
            Picasso.get().load(profileimage).placeholder(R.drawable.profile).into(profileImage);
        }

        public void setDate (String date){
            userStatus.setText(date);
        }

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            SendToMainActivity();
        }
        return super.onOptionsItemSelected(item);
    }

    private void SendToMainActivity() {
        Intent mainIntent = new Intent(FriendsActivity.this, MainActivity.class);
        startActivity(mainIntent);
    }

}
