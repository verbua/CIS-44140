package com.cis44140.team3.socialdistance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class ProfileActivity extends AppCompatActivity {

    private TextView profileFullName, profileUserName, profileUserStatus, profileBirthday, profileRelationShipStatus, profileGender, profilePhoneNumber, profile_post_counter;
    private TextView likeCounterTextView, commentsCounterTextView,profile_views_counter, viewsCounterTextView, profile_friends_counter, profile_friends_label, profile_posts_label, profile_likes_counter;
    private CircleImageView profileImage;

    private DatabaseReference profileUserRef, PostsRef, likesRef, friendsRef;
    private FirebaseAuth mAuth;
    private Query postsQuery;

    private String current_user_id;
    private RecyclerView profile_post_recycler;

    boolean likeChecker = false;

    private Toolbar mToolbar;

    private int friendCount = 0;
    private int postsCount = 0;
    private int likesCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        mAuth = FirebaseAuth.getInstance();
        current_user_id = mAuth.getCurrentUser().getUid();

        friendsRef = FirebaseDatabase.getInstance().getReference().child("Friends").child(current_user_id);
        mToolbar = (Toolbar) findViewById(R.id.profile_toolbar);
        mToolbar.getOverflowIcon().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(mToolbar);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);

        profileUserRef = FirebaseDatabase.getInstance().getReference().child("Users").child(current_user_id);
        PostsRef = FirebaseDatabase.getInstance().getReference().child("Posts");
        likesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
        postsQuery = PostsRef.orderByChild("uid").equalTo(current_user_id);

        profile_post_recycler = findViewById(R.id.profile_post_recycler);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        profile_post_recycler.setLayoutManager(linearLayoutManager);

        DisplayUsersPosts();

        profileImage = (CircleImageView) findViewById(R.id.profile_profile_image);
        profileUserName = (TextView) findViewById(R.id.profile_header_user_name);
        profileUserStatus = (TextView) findViewById(R.id.profile_header_user_status);
        profileBirthday = (TextView) findViewById(R.id.profile_attribute_birthday);
        profileRelationShipStatus = (TextView) findViewById(R.id.profile_attribute_relationship_status);
        profileGender = (TextView) findViewById(R.id.profile_attribute_gender);
        profilePhoneNumber = (TextView) findViewById(R.id.profile_attribute_phone_number);
        profile_friends_counter = findViewById(R.id.profile_friends_counter);
        profile_friends_label = findViewById(R.id.profile_friends_label);
        profile_posts_label = findViewById(R.id.profile_posts_label);
        profile_post_counter = findViewById(R.id.profile_post_counter);
        likeCounterTextView = (TextView) findViewById(R.id.likeCounterTextView);
        commentsCounterTextView = (TextView) findViewById(R.id.commentsCountTextView);
        viewsCounterTextView = (TextView) findViewById(R.id.watcherCounterTextView);
        profile_likes_counter = findViewById(R.id.profile_likes_counter);
        profile_views_counter = findViewById(R.id.profile_views_counter);

        profileUserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String profileImageUrl = null;
                    if (dataSnapshot.hasChild("profileimage")) {
                        profileImageUrl = Objects.requireNonNull(dataSnapshot.child("profileimage").getValue()).toString();
                        Picasso.get().load(profileImageUrl).placeholder(R.drawable.profile).into(profileImage);
                    }
                    String username = Objects.requireNonNull(dataSnapshot.child("username").getValue()).toString();
                    String phoneNo = Objects.requireNonNull(dataSnapshot.child("phonenumber").getValue()).toString();
                    String birthday = Objects.requireNonNull(dataSnapshot.child("dob").getValue()).toString();
                    String genderDesc = Objects.requireNonNull(dataSnapshot.child("gender").getValue()).toString();
                    String relationStatus = Objects.requireNonNull(dataSnapshot.child("relationshipstatus").getValue().toString());
                    String userStatus = Objects.requireNonNull(dataSnapshot.child("status").getValue().toString());
                    String fullCompleteName = Objects.requireNonNull(dataSnapshot.child("fullname").getValue().toString());
                    String views = dataSnapshot.child("views").getValue().toString();

                    Picasso.get().load(profileImageUrl).placeholder(R.drawable.profile);

                    getSupportActionBar().setTitle(fullCompleteName);

                    profileUserName.setText(username);
                    profileUserStatus.setText(userStatus);
                    profileBirthday.setText(birthday);
                    profileRelationShipStatus.setText(relationStatus);
                    profileGender.setText(genderDesc);
                    profilePhoneNumber.setText(phoneNo);
                    profile_views_counter.setText(views);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        friendsRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    friendCount = (int) dataSnapshot.getChildrenCount();

                    if (friendCount == 1) {
                        profile_friends_label.setText("friend");
                        profile_friends_label.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        //LinearLayout.LayoutParams params = (LinearLayout.LayoutParams)profile_friends_label.getLayoutParams();
                        //params.setMargins(30, 0, 0, 0);
                        //profile_friends_label.setLayoutParams(params);
                    }

                    profile_friends_counter.setText(String.valueOf(friendCount));
                    profile_friends_counter.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                } else {
                    // placeholder for no friends
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        PostsRef.orderByChild("uid").equalTo(current_user_id)
            .addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        postsCount = (int) dataSnapshot.getChildrenCount();
                        if (postsCount == 1) {
                            profile_posts_label.setText("post");
                            profile_posts_label.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                        }
                        profile_post_counter.setText(String.valueOf(postsCount));
                        profile_post_counter.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

                    } else {
                        //placeholder if no posts found
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        profileUserRef.child("likes").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    likesCount = Integer.parseInt(dataSnapshot.getValue().toString());
                    profile_likes_counter.setText(String.valueOf(likesCount));
                    profile_likes_counter.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        profileUserRef.child("views").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    int viewCounter = Integer.parseInt(dataSnapshot.getValue().toString());
                    profile_views_counter.setText(String.valueOf(viewCounter));
                    profile_views_counter.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            SendToMainActivity();
        } else {
            switch (id) {
                case R.id.profile_settings_menuitem:
                    SendUserToSettingsActivity();
                    break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu) {
        getMenuInflater().inflate(R.menu.profile_top_toolbar, menu);

        return true;
    }

    private void SendToMainActivity() {
        Intent mainIntent = new Intent(ProfileActivity.this, MainActivity.class);
        startActivity(mainIntent);
    }
    private void SendUserToSettingsActivity() {
        Intent settingIntent = new Intent(ProfileActivity.this, SettingsActivity.class);
        startActivity(settingIntent);
    }


    private void DisplayUsersPosts() {

        FirebaseRecyclerOptions<post> searchOptions = new FirebaseRecyclerOptions.Builder<post> ()
                .setQuery(postsQuery, post.class).build();

        FirebaseRecyclerAdapter<post, myPostViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<post, myPostViewHolder>(searchOptions) {
                    @Override
                    protected void onBindViewHolder(@NonNull myPostViewHolder holder, int position, @NonNull post model) {
                        holder.fullname.setText(model.getFullname());
                        Picasso.get().load(model.getPostimage()).into(holder.postImage);
                        if (TextUtils.isEmpty(model.getProfileimage())) {
                            Picasso.get().load(model.getProfileimage()).into(holder.profileImage);
                        }
                        holder.date.setText(model.getDate());
                        holder.time.setText(model.getTime());
                        holder.photoDescription.setText(model.getDescription());
                        holder.actualUsername.setText(model.getUsername());
                    }

                    @NonNull
                    @Override
                    public myPostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.all_post_layout, parent, false);
                        myPostViewHolder viewHolder = new myPostViewHolder(view);
                        return viewHolder;
                    }
                };

        profile_post_recycler.setAdapter(firebaseRecyclerAdapter);


    }

    public static class myPostViewHolder extends RecyclerView.ViewHolder {

        TextView fullname, date, time, photoDescription, actualUsername;
        ImageView postImage;
        CircleImageView profileImage;

        public myPostViewHolder(@NonNull View itemView) {
            super(itemView);

            actualUsername = itemView.findViewById(R.id.post_actual_username);
            fullname = itemView.findViewById(R.id.post_full_name);
            date = itemView.findViewById(R.id.post_date);
            time = itemView.findViewById(R.id.post_time);
            postImage = itemView.findViewById(R.id.post_image);
            profileImage = itemView.findViewById(R.id.post_profile_image);
            photoDescription = itemView.findViewById(R.id.post_description);

        }

    }

}
