package com.cis44140.team3.socialdistance;

public class Comments {

    public String comment;
    public String date;
    public String fullname;
    public String profileimage;
    public String time;
    public String timestamp;
    public String uid;
    public String username;

    public Comments() {

    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getProfileimage() {
        return profileimage;
    }

    public void setProfileimage(String profileimage) {
        this.profileimage = profileimage;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Comments(String comment, String date, String fullname, String profileimage, String time, String timestamp, String uid, String username) {
        this.comment = comment;
        this.date = date;
        this.fullname = fullname;
        this.profileimage = profileimage;
        this.time = time;
        this.timestamp = timestamp;
        this.uid = uid;
        this.username = username;
    }

}
