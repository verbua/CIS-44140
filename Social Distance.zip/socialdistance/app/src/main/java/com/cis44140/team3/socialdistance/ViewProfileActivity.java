package com.cis44140.team3.socialdistance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.Toolbar;
import de.hdodenhof.circleimageview.CircleImageView;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.Objects;

import static com.cis44140.team3.socialdistance.R.drawable.ic_friend_add;
import static com.cis44140.team3.socialdistance.R.drawable.ic_friend_add_greyed_out;

public class ViewProfileActivity extends AppCompatActivity {

    private TextView profileFullName, profileUserName, profileUserStatus, profileBirthday, profileRelationShipStatus, profileGender, profilePhoneNumber;
    private CircleImageView profileImage;
    private Button declineFriendRequest;
    private DatabaseReference profileUserRef, UsersRef;
    private FirebaseAuth mAuth;
    private String requesting_user_id, reciever_user_id, CURRENT_STATE;
    private Toolbar mToolbar;
    private int isPending = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        mAuth = FirebaseAuth.getInstance();

        requesting_user_id = mAuth.getCurrentUser().getUid();
        reciever_user_id = getIntent().getExtras().get("visit_user").toString();
        CURRENT_STATE = "not_friends";

        UsersRef = FirebaseDatabase.getInstance().getReference().child("Users");

        mToolbar = (Toolbar) findViewById(R.id.viewProfileToolbar);
        mToolbar.getOverflowIcon().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(mToolbar);

        profileImage = (CircleImageView) findViewById(R.id.viewProfileProfileImage);
        profileUserName = (TextView) findViewById(R.id.viewProfileUsername);
        profileUserStatus = (TextView) findViewById(R.id.viewProfileUserStatus);
        profileBirthday = (TextView) findViewById(R.id.viewProfileAttributeBirthday);
        profileRelationShipStatus = (TextView) findViewById(R.id.viewProfileAttributeRelationShipStatus);
        profileGender = (TextView) findViewById(R.id.viewProfileAttributeGender);

        declineFriendRequest = (Button) findViewById(R.id.declineFriendRequest);

        UsersRef.child(reciever_user_id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String profileImageUrl = Objects.requireNonNull(dataSnapshot.child("profileimage").getValue()).toString();
                    String username = Objects.requireNonNull(dataSnapshot.child("username").getValue()).toString();
                    String birthday = Objects.requireNonNull(dataSnapshot.child("dob").getValue()).toString();
                    String genderDesc = Objects.requireNonNull(dataSnapshot.child("gender").getValue()).toString();
                    String relationStatus = Objects.requireNonNull(dataSnapshot.child("relationshipstatus").getValue().toString());
                    String userStatus = Objects.requireNonNull(dataSnapshot.child("status").getValue().toString());
                    String fullName = Objects.requireNonNull(dataSnapshot.child("fullname").getValue().toString());

                    getSupportActionBar().setTitle(fullName);

                    Picasso.get().load(profileImageUrl).placeholder(R.drawable.profile).into(profileImage);

                    profileUserName.setText(username);
                    profileUserStatus.setText(userStatus);
                    profileBirthday.setText(birthday);
                    profileRelationShipStatus.setText(relationStatus);
                    profileGender.setText(genderDesc);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        if (!requesting_user_id.equals(reciever_user_id)) {

        } else {

        }

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            SendUserToSearchActivity();
        } else {
            switch (id) {
                case R.id.view_profile_add_friend:
                    SendFriendRequestButton();
                    if (isPending == 1) {
                        item.setIcon(ic_friend_add);
                        Toast.makeText(ViewProfileActivity.this, "Friend request cancelled", Toast.LENGTH_SHORT).show();
                        isPending = 0;
                    } else if (isPending == 0) {
                        item.setIcon(ic_friend_add_greyed_out);
                        Toast.makeText(ViewProfileActivity.this, "Friend request sent!", Toast.LENGTH_SHORT).show();
                        isPending = 1;
                    } else {
                        item.setVisible(false);
                        item.setEnabled(false);
                    }
                    break;
                case R.id.view_profile_report_menuitem:
                    Toast.makeText(ViewProfileActivity.this, "User Reported", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void SendFriendRequestButton() {

    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu) {
        getMenuInflater().inflate(R.menu.view_profile_top_menu, menu);

        return true;
    }

    private void SendUserToSearchActivity() {
        Intent searchIntent = new Intent(ViewProfileActivity.this, FindFriendsActivity.class);
        startActivity(searchIntent);
    }

}
