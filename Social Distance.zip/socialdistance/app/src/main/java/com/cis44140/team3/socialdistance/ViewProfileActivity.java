package com.cis44140.team3.socialdistance;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import de.hdodenhof.circleimageview.CircleImageView;

public class ViewProfileActivity extends AppCompatActivity {

    private TextView profileUserName, profileUserStatus, profileBirthday, profileRelationShipStatus, profileGender, viewProfileViewsCounter;
    private CircleImageView profileImage;
    private Button declineFriendRequest, acceptFriendRequest;
    private DatabaseReference UsersRef, FriendRequestRef, FriendsRef, NotificationsRef;
    private String requesting_user_id, reciever_user_id, CURRENT_STATE, previousIntent, postKey;
    private Toolbar mToolbar;

    private String profileImageUrl, username, fullName;

    private boolean isSelf = false;

    private int views;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        requesting_user_id = mAuth.getCurrentUser().getUid();
        reciever_user_id = getIntent().getExtras().get("visit_user").toString();

        previousIntent = "back";

        Bundle intentExtras = getIntent().getExtras();

        if (intentExtras.containsKey("post_key")) {
            postKey = getIntent().getExtras().get("post_key").toString();
        }
        if (intentExtras.containsKey("previous_intent")) {
            previousIntent = getIntent().getExtras().get("previous_intent").toString();
        }

        CURRENT_STATE = "not_friends";

        UsersRef = FirebaseDatabase.getInstance().getReference().child("Users");
        FriendRequestRef = FirebaseDatabase.getInstance().getReference().child("FriendRequests");
        FriendsRef = FirebaseDatabase.getInstance().getReference().child("Friends");
        NotificationsRef = FirebaseDatabase.getInstance().getReference().child("Notifications");

        mToolbar = (Toolbar) findViewById(R.id.viewProfileToolbar);
        mToolbar.getOverflowIcon().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(mToolbar);

        profileImage = (CircleImageView) findViewById(R.id.viewProfileProfileImage);
        profileUserName = (TextView) findViewById(R.id.viewProfileUsername);
        profileUserStatus = (TextView) findViewById(R.id.viewProfileUserStatus);
        profileBirthday = (TextView) findViewById(R.id.viewProfileAttributeBirthday);
        profileRelationShipStatus = (TextView) findViewById(R.id.viewProfileAttributeRelationShipStatus);
        profileGender = (TextView) findViewById(R.id.viewProfileAttributeGender);
        viewProfileViewsCounter = findViewById(R.id.viewProfileViewsCounter);

        declineFriendRequest = (Button) findViewById(R.id.declineFriendRequest);
        acceptFriendRequest = findViewById(R.id.acceptFriendRequest);

        UsersRef.child(reciever_user_id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    if (dataSnapshot.hasChild("profileimage")) {
                        profileImageUrl = Objects.requireNonNull(dataSnapshot.child("profileimage").getValue()).toString();
                        Picasso.get().load(profileImageUrl).placeholder(R.drawable.profile).into(profileImage);
                    }
                    username = Objects.requireNonNull(dataSnapshot.child("username").getValue()).toString();
                    String birthday = Objects.requireNonNull(dataSnapshot.child("dob").getValue()).toString();
                    String genderDesc = Objects.requireNonNull(dataSnapshot.child("gender").getValue()).toString();
                    String relationStatus = Objects.requireNonNull(dataSnapshot.child("relationshipstatus").getValue().toString());
                    String userStatus = Objects.requireNonNull(dataSnapshot.child("status").getValue().toString());
                    fullName = Objects.requireNonNull(dataSnapshot.child("fullname").getValue().toString());

                    getSupportActionBar().setTitle(fullName);



                    profileUserName.setText(username);
                    profileUserStatus.setText(userStatus);
                    profileBirthday.setText(birthday);
                    profileRelationShipStatus.setText(relationStatus);
                    profileGender.setText(genderDesc);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        if (!requesting_user_id.equals(reciever_user_id)) {
            CheckAddFriendIcon();
        } else {
            isSelf = true;
        }

        if (!reciever_user_id.equals(requesting_user_id)) {
            UsersRef.child(reciever_user_id).child("views").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        int viewCounter = Integer.parseInt(dataSnapshot.getValue().toString()) + 1;
                        viewProfileViewsCounter.setText(String.valueOf(viewCounter));
                        UsersRef.child(reciever_user_id).child("views").setValue(viewCounter);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

    }

    private void CheckAddFriendIcon() {
        FriendRequestRef.child(requesting_user_id)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild(reciever_user_id)) {
                            String requestType = dataSnapshot.child(reciever_user_id).child("requesttype").getValue().toString();

                            if (requestType.equals("sent")) {
                                CURRENT_STATE = "request_sent";
                                RefreshAddFriendIcon(CURRENT_STATE);
                            } else if (requestType.equals("received")) {
                                CURRENT_STATE = "request_received";
                                RefreshAddFriendIcon(CURRENT_STATE);
                            }

                        } else {
                            FriendsRef.child(requesting_user_id).addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if (dataSnapshot.hasChild(reciever_user_id)) {
                                        CURRENT_STATE = "friends";
                                        RefreshAddFriendIcon(CURRENT_STATE);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            SendUserToSearchActivity();
        } else {
            switch (id) {
                case R.id.view_profile_add_friend:
                    SendFriendRequestButton();
                    break;
                case R.id.view_profile_report_menuitem:
                    Toast.makeText(ViewProfileActivity.this, "User Reported", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
        return super.onOptionsItemSelected(item);
    }



    private void SendFriendRequestButton() {

        if (CURRENT_STATE.equals("not_friends")) {
            FriendRequestRef.child(requesting_user_id).child(reciever_user_id)
                    .child("requesttype").setValue("sent").addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        FriendRequestRef.child(reciever_user_id).child(requesting_user_id)
                                .child("requesttype").setValue("received").addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {

                                    HashMap friendRequestMap = new HashMap<>();
                                    friendRequestMap.put("from",requesting_user_id);
                                    friendRequestMap.put("type","friendrequest");

                                    NotificationsRef.child(reciever_user_id).push().setValue(friendRequestMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(ViewProfileActivity.this, "Friend request sent!", Toast.LENGTH_SHORT).show();
                                                CURRENT_STATE = "request_sent";
                                                RefreshAddFriendIcon(CURRENT_STATE);
                                            }
                                        }
                                    });

                                }
                            }
                        });
                    }
                }
            });
        }
        if (CURRENT_STATE.equals("request_sent")) {
            CancelFriendRequest();
            Toast.makeText(ViewProfileActivity.this, "Friend Request Cancelled", Toast.LENGTH_SHORT).show();
        }
        if (CURRENT_STATE.equals("request_received")) {
            RefreshAddFriendIcon(CURRENT_STATE);
        }
        if (CURRENT_STATE.equals("friends")) {
            RefreshAddFriendIcon(CURRENT_STATE);
            RemoveFriend();
        }

    }

    private void RemoveFriend() {
        Toast.makeText(ViewProfileActivity.this, "Friend removed", Toast.LENGTH_SHORT).show();
        FriendsRef.child(requesting_user_id).child(reciever_user_id).removeValue()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            FriendsRef.child(reciever_user_id).child(requesting_user_id)
                                    .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        CURRENT_STATE = "not_friends";
                                        RefreshAddFriendIcon(CURRENT_STATE);
                                    }
                                }
                            });
                        }
                    }
                });
    }

    private void AcceptFriendRequest() {

        Toast.makeText(ViewProfileActivity.this, "Friend Request Accepted", Toast.LENGTH_SHORT).show();

        Calendar calFordDate = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("MMMM dd, yyyy");
        final String saveCurrentDate = currentDate.format(calFordDate.getTime());

        SimpleDateFormat currentTime = new SimpleDateFormat("h:mm a");
        final String saveCurrentTime = currentTime.format(calFordDate.getTime());

        Calendar calTemp = Calendar.getInstance();
        SimpleDateFormat tempTime = new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");
        final String timeString = tempTime.format(calTemp.getTime());

        FriendsRef.child(requesting_user_id).child(reciever_user_id).child("date").setValue(saveCurrentDate);
        FriendsRef.child(requesting_user_id).child(reciever_user_id).child("time").setValue(saveCurrentTime);
        FriendsRef.child(requesting_user_id).child(reciever_user_id).child("timestamp").setValue(timeString)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            FriendsRef.child(reciever_user_id).child(requesting_user_id).child("timestamp").setValue(timeString);
                            FriendsRef.child(reciever_user_id).child(requesting_user_id).child("time").setValue(saveCurrentTime);
                            FriendsRef.child(reciever_user_id).child(requesting_user_id).child("date").setValue(saveCurrentDate)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                FriendRequestRef.child(requesting_user_id).child(reciever_user_id).removeValue()
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<Void> task) {
                                                                if (task.isSuccessful()) {
                                                                    FriendRequestRef.child(reciever_user_id).child(requesting_user_id)
                                                                            .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                        @Override
                                                                        public void onComplete(@NonNull Task<Void> task) {
                                                                            if (task.isSuccessful()) {
                                                                                CURRENT_STATE = "friends";
                                                                                RefreshAddFriendIcon(CURRENT_STATE);
                                                                                declineFriendRequest.setEnabled(false);
                                                                                declineFriendRequest.setVisibility(View.GONE);
                                                                                acceptFriendRequest.setEnabled(false);
                                                                                acceptFriendRequest.setVisibility(View.GONE);
                                                                            }
                                                                        }
                                                                    });
                                                                }
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                    }
                });

    }

    private void RefreshAddFriendIcon(String current_state) {
        Menu menu = mToolbar.getMenu();
        if (current_state.equals("request_sent")) {
            if (menu.findItem(R.id.view_profile_add_friend) != null) {
                menu.findItem(R.id.view_profile_add_friend).setIcon(R.drawable.ic_friend_add_greyed_out);
            }
        } else if (current_state.equals("not_friends")) {
            if (menu.findItem(R.id.view_profile_add_friend) != null) {
                menu.findItem(R.id.view_profile_add_friend).setIcon(R.drawable.ic_friend_add);
                menu.findItem(R.id.view_profile_add_friend).setVisible(true);
                menu.findItem(R.id.view_profile_add_friend).setEnabled(true);
                declineFriendRequest.setEnabled(false);
                declineFriendRequest.setVisibility(View.GONE);
                acceptFriendRequest.setEnabled(false);
                acceptFriendRequest.setVisibility(View.GONE);
            }
        } else if (current_state.equals("request_received")) {
            if (menu.findItem(R.id.view_profile_add_friend) != null) {
                menu.findItem(R.id.view_profile_add_friend).setVisible(false);
                menu.findItem(R.id.view_profile_add_friend).setEnabled(false);
                declineFriendRequest.setVisibility(View.VISIBLE);
                declineFriendRequest.setEnabled(true);
                acceptFriendRequest.setVisibility(View.VISIBLE);
                acceptFriendRequest.setEnabled(true);

                declineFriendRequest.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DeclineFriendRequest();
                    }
                });

                acceptFriendRequest.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        AcceptFriendRequest();
                    }
                });

            }
        } else if (current_state.equals("friends")) {
            if (menu.findItem(R.id.view_profile_add_friend) != null) {
                menu.findItem(R.id.view_profile_add_friend).setVisible(true);
                menu.findItem(R.id.view_profile_add_friend).setEnabled(true);
                menu.findItem(R.id.view_profile_add_friend).setIcon(R.drawable.ic_remove);
            }
        }
    }

    private void DeclineFriendRequest() {
        Toast.makeText(ViewProfileActivity.this, "Friend Request Declined", Toast.LENGTH_SHORT).show();
        CancelFriendRequest();
    }

    private void CancelFriendRequest() {
        FriendRequestRef.child(requesting_user_id).child(reciever_user_id).removeValue()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    FriendRequestRef.child(reciever_user_id).child(requesting_user_id)
                            .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                CURRENT_STATE = "not_friends";
                                RefreshAddFriendIcon(CURRENT_STATE);
                            }
                        }
                    });
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu) {
        if (!isSelf) {
            getMenuInflater().inflate(R.menu.view_profile_top_menu, menu);
        }
        return true;
    }

    private void SendUserToSearchActivity() {
        Intent searchIntent = new Intent(ViewProfileActivity.this, FindFriendsActivity.class);
        Intent clickPostIntent = new Intent(ViewProfileActivity.this, ClickPostActivity.class);
        Intent friendsIntent = new Intent(ViewProfileActivity.this, FriendsActivity.class);
        Intent messageChatIntent = new Intent(ViewProfileActivity.this, MessageActivity.class);

        if (previousIntent.equals("back")) {
            startActivity(searchIntent);
        } else if (previousIntent.equals("friends")) {
            startActivity(friendsIntent);
        } else if (previousIntent.equals("messages")) {
            messageChatIntent.putExtra("user_full_name", fullName);
            messageChatIntent.putExtra("user_name", username);
            messageChatIntent.putExtra("user_profile_image", profileImageUrl);
            messageChatIntent.putExtra("visit_user_id", reciever_user_id);
            startActivity(messageChatIntent);
        } else {
            clickPostIntent.putExtra("postKey", postKey);
            clickPostIntent.putExtra("previous_activity", "viewProfile");
            startActivity(clickPostIntent);
        }

    }

}
