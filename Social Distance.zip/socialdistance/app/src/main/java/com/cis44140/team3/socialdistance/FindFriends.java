package com.cis44140.team3.socialdistance;

public class FindFriends {
    public String profileimage;
    public String status;
    public String username;
    public String fullname;

    public FindFriends() {
    }

    public String getProfileimage() {
        return profileimage;
    }

    public void setProfileimage(String profileimage) {
        this.profileimage = profileimage;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public FindFriends(String profileimage, String status, String username, String fullname) {
        this.profileimage = profileimage;
        this.status = status;
        this.username = username;
        this.fullname = fullname;
    }

}
