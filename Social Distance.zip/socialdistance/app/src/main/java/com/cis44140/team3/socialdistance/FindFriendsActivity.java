package com.cis44140.team3.socialdistance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.Objects;

public class FindFriendsActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private Button searchButton;
    private EditText searchBar;
    private RecyclerView recycleView;
    private DatabaseReference allUsersRef;
    private Query searchQuery;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_friends);

        allUsersRef = FirebaseDatabase.getInstance().getReference().child("Users");

        mToolbar = (Toolbar) findViewById(R.id.find_friend_top_bar);
        setSupportActionBar(mToolbar);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Search");
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);

        recycleView = (RecyclerView) findViewById(R.id.find_friends_result_list);
        recycleView.setHasFixedSize(true);
        recycleView.setLayoutManager(new LinearLayoutManager(this));

        searchButton = (Button) findViewById(R.id.find_friends_search_button);
        searchButton.setClickable(true);
        searchBar = (EditText) findViewById(R.id.find_friends_search_box);

        searchBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE)) {
                    searchButton.performClick();
                }
                return false;
            }
        });

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchInput = searchBar.getText().toString();
                SearchForFriends(searchInput);
            }
        });

    }

    private void SearchForFriends(String searchInput) {

        if (!TextUtils.isEmpty(searchInput)) {
            searchQuery = FirebaseDatabase.getInstance().getReference().child("Users").orderByChild("fullname")
                    .startAt(searchInput).endAt(searchInput + "\uf8ff");
        } else {
            searchQuery = FirebaseDatabase.getInstance().getReference().child("Users").orderByChild("fullname");
        }
        FirebaseRecyclerOptions<FindFriends> searchOptions = new FirebaseRecyclerOptions.Builder<FindFriends> ()
                .setQuery(searchQuery, FindFriends.class).build();

        FirebaseRecyclerAdapter<FindFriends, FindFriendsViewHolder> firebaseRecyclerAdapter
                = new FirebaseRecyclerAdapter<FindFriends, FindFriendsViewHolder>(searchOptions) {
            @Override
            protected void onBindViewHolder(@NonNull FindFriendsViewHolder holder, int position, @NonNull FindFriends model) {

                final String postKey = getRef(position).getKey();

                holder.fullName.setText(model.getFullname());
                holder.userStatus.setText(model.getStatus());
                holder.userName.setText(model.getUsername());
                Picasso.get().load(model.getProfileimage()).placeholder(R.drawable.profile).into(holder.profileImage);

                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent profileIntent = new Intent(FindFriendsActivity.this, ViewProfileActivity.class);
                        profileIntent.putExtra("visit_user", postKey);
                        startActivity(profileIntent);
                    }
                });
                
            }

            @NonNull
            @Override
            public FindFriendsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.all_users_display_layout, parent, false);
                FindFriendsViewHolder findFriendsViewHolder = new FindFriendsViewHolder(view);
                return findFriendsViewHolder;
            }
        };

        recycleView.setAdapter(firebaseRecyclerAdapter);
        firebaseRecyclerAdapter.startListening();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            SendToMainActivity();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

    private void SendToMainActivity() {
        Intent mainIntent = new Intent(FindFriendsActivity.this, MainActivity.class);
        startActivity(mainIntent);
    }

    public static class FindFriendsViewHolder extends RecyclerView.ViewHolder {

        CircleImageView profileImage;
        TextView userName, fullName, userStatus;

        public FindFriendsViewHolder(@NonNull View itemView) {
            super(itemView);
            
            profileImage = (CircleImageView) itemView.findViewById(R.id.all_user_profile_image);
            userName = (TextView) itemView.findViewById(R.id.all_user_username);
            fullName = (TextView) itemView.findViewById(R.id.all_user_full_name);
            userStatus = (TextView) itemView.findViewById(R.id.all_user_user_status);
        }
    }

}
