package com.cis44140.team3.socialdistance;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class ClickPostActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private ImageView postImageView, likesImageView;
    private TextView descriptionEditText, authorTextView, likeCounterTextView, commentsCounterTextView, viewsCounterTextView;
    private CircleImageView profileImageCircle, commentProfileImage;
    private EditText commentEditText;
    private ImageButton sendButton;
    private String current_user_id, databaseuserid, description, image, author, profileImage;
    private DatabaseReference clickPostRef, commentsRef, viewsRef;
    private String postKey;
    private MenuItem editPost, deletePost;
    private RecyclerView commentsRecycler;
    private FirebaseAuth mAuth;
    private DatabaseReference UsersRef, LikesRef;
    boolean likeChecker = false;
    boolean zoomOut;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_click_post);

        mAuth = FirebaseAuth.getInstance();
        current_user_id = mAuth.getCurrentUser().getUid();

        UsersRef = FirebaseDatabase.getInstance().getReference().child("Users");
        LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");

        postKey = getIntent().getExtras().get("postKey").toString();
        clickPostRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(postKey);
        commentsRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(postKey).child("comments");
        viewsRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(postKey).child("views");

        postImageView = (ImageView) findViewById(R.id.postImageView);
        descriptionEditText = (TextView) findViewById(R.id.descriptionEditText);
        authorTextView = (TextView) findViewById(R.id.authorTextView);
        commentEditText = (EditText) findViewById(R.id.commentEditText);
        sendButton = (ImageButton) findViewById(R.id.sendButton);
        profileImageCircle = (CircleImageView) findViewById(R.id.click_post_profile_image);
        commentProfileImage = findViewById(R.id.commentProfilePicture);

        likesImageView = (ImageView) findViewById(R.id.likesImageView);

        likeCounterTextView = (TextView) findViewById(R.id.likeCounterTextView);
        likeCounterTextView = (TextView) findViewById(R.id.likeCounterTextView);
        commentsCounterTextView = (TextView) findViewById(R.id.commentsCountTextView);
        viewsCounterTextView = (TextView) findViewById(R.id.watcherCounterTextView);

        mToolbar = (Toolbar) findViewById(R.id.post_details_include_bar);
        mToolbar.getOverflowIcon().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        setSupportActionBar(mToolbar);

        Objects.requireNonNull(getSupportActionBar()).setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Post Details");
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);

        commentsRecycler = (RecyclerView) findViewById(R.id.commentsRecyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(false);
        linearLayoutManager.setStackFromEnd(true);
        commentsRecycler.setLayoutManager(linearLayoutManager);

        DisplayCurrentComments();

        clickPostRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {

                    description = dataSnapshot.child("description").getValue().toString();
                    image = dataSnapshot.child("postimage").getValue().toString();
                    author = dataSnapshot.child("fullname").getValue().toString();
                    profileImage = dataSnapshot.child("profileimage").getValue().toString();
                    databaseuserid = dataSnapshot.child("uid").getValue().toString();

                    descriptionEditText.setText(description);
                    authorTextView.setText(author);
                    Picasso.get().load(image).into(postImageView);
                    Picasso.get().load(profileImage).into(profileImageCircle);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UsersRef.child(current_user_id).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            String username = dataSnapshot.child("username").getValue().toString();
                            String fullName = dataSnapshot.child("fullname").getValue().toString();

                            final String profileimage = dataSnapshot.child("profileimage").getValue().toString();
                            ValidateComment(username, fullName, profileimage);
                            commentEditText.setText("");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

        postImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(ClickPostActivity.this, "Full screen coming soon!", Toast.LENGTH_SHORT).show();
            }
        });

        authorTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent profileIntent = new Intent(ClickPostActivity.this, ViewProfileActivity.class);
                profileIntent.putExtra("visit_user", databaseuserid);
                profileIntent.putExtra("post_key", postKey);
                profileIntent.putExtra("previous_intent", "view_post");
                startActivity(profileIntent);
            }
        });

        profileImageCircle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent profileIntent = new Intent(ClickPostActivity.this, ViewProfileActivity.class);
                profileIntent.putExtra("visit_user", databaseuserid);
                profileIntent.putExtra("post_key", postKey);
                profileIntent.putExtra("previous_intent", "view_post");
                startActivity(profileIntent);
            }
        });

    }

    public static class CommentsViewHolder extends RecyclerView.ViewHolder {

        CircleImageView profileImage;
        TextView FullName, UserName, Date, Time, Comment;
        DatabaseReference LikesRef;
        FirebaseAuth mAuth;
        String current_user_id;
        int numberOfLikes,numberOfComments, numberOfViews;

        public CommentsViewHolder(@NonNull View itemView) {
            super(itemView);

            mAuth = FirebaseAuth.getInstance();
            current_user_id = mAuth.getCurrentUser().getUid();
            profileImage = itemView.findViewById(R.id.commentProfilePicture);
            FullName = itemView.findViewById(R.id.commentFullName);
            UserName = itemView.findViewById(R.id.commentUserName);
            Date = itemView.findViewById(R.id.commentDate);
            Time = itemView.findViewById(R.id.commentTime);
            Comment = itemView.findViewById(R.id.commentCommentText);

        }

        public void setLikeButtonStatus(final String postKey, final ImageView likesImageView, final TextView likeCounterTextView) {
            LikesRef = FirebaseDatabase.getInstance().getReference().child("Likes");
            LikesRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child(postKey).hasChild(current_user_id)) {
                        numberOfLikes = (int) dataSnapshot.child(postKey).getChildrenCount();
                        likesImageView.setImageResource(R.drawable.ic_thumb_up_red);
                        likeCounterTextView.setText(Integer.toString(numberOfLikes));
                    } else {
                        numberOfLikes = (int) dataSnapshot.child(postKey).getChildrenCount();
                        likesImageView.setImageResource(R.drawable.ic_thumb_up);
                        likeCounterTextView.setText(Integer.toString(numberOfLikes));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        public void setCommentButtonStatus(String postKey, final TextView commentsCounterTextView) {
            DatabaseReference CommentsRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(postKey).child("comments");
            CommentsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        numberOfComments = (int) dataSnapshot.getChildrenCount();
                        commentsCounterTextView.setText(Integer.toString(numberOfComments));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        public void setViewsButtonStatus(String postKey, final TextView viewsCounterTextView) {
            DatabaseReference viewsRef = FirebaseDatabase.getInstance().getReference().child("Posts").child(postKey).child("views");
            viewsRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        numberOfViews = (int) Integer.valueOf(dataSnapshot.getValue().toString());
                        viewsCounterTextView.setText(Integer.toString(numberOfViews));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    public void DisplayCurrentComments() {
        FirebaseRecyclerOptions<Comments> searchOptions = new FirebaseRecyclerOptions.Builder<Comments> ()
                .setQuery(commentsRef, Comments.class).build();

        FirebaseRecyclerAdapter<Comments, CommentsViewHolder> firebaseRecyclerAdapter =
                new FirebaseRecyclerAdapter<Comments, CommentsViewHolder>(searchOptions) {
                    @Override
                    protected void onBindViewHolder(@NonNull CommentsViewHolder holder, int position, @NonNull Comments model) {
                        holder.FullName.setText(model.getFullname());
                        holder.Date.setText(model.getDate());
                        holder.Time.setText(model.getTime());
                        holder.UserName.setText(model.getUsername());
                        holder.Comment.setText(model.getComment());
                        Picasso.get().load(model.getProfileimage()).placeholder(R.drawable.profile).into(holder.profileImage);

                        final String holderUser = holder.current_user_id;

                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent profileIntent = new Intent(ClickPostActivity.this, ViewProfileActivity.class);
                                profileIntent.putExtra("visit_user", holderUser);
                                profileIntent.putExtra("previous_intent", "view_post");
                                profileIntent.putExtra("post_key", postKey);
                                startActivity(profileIntent);
                            }
                        });

                        holder.setLikeButtonStatus(postKey, likesImageView, likeCounterTextView);
                        holder.setCommentButtonStatus(postKey, commentsCounterTextView);
                        holder.setViewsButtonStatus(postKey, viewsCounterTextView);

                        likesImageView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                likeChecker = true;
                                LikesRef.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if (likeChecker) {
                                            if (dataSnapshot.child(postKey).hasChild(current_user_id)) {
                                                LikesRef.child(postKey).child(current_user_id).removeValue();
                                                likeChecker = false;
                                            } else {
                                                LikesRef.child(postKey).child(current_user_id).setValue(true);
                                                likeChecker = false;
                                            }
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });
                            }
                        });


                    }

                    @NonNull
                    @Override
                    public CommentsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.all_comments_layout, parent, false);
                        ClickPostActivity.CommentsViewHolder viewHolder = new ClickPostActivity.CommentsViewHolder(view);
                        return viewHolder;
                    }
                };

        commentsRecycler.setAdapter(firebaseRecyclerAdapter);
        firebaseRecyclerAdapter.startListening();
    }

    private void ValidateComment(String username, String fullname, String profileimage) {
        String commentText = commentEditText.getText().toString();

        if (TextUtils.isEmpty(username)) {
            Toast.makeText(this, "Please enter text to comment.", Toast.LENGTH_SHORT).show();
        }  else if (TextUtils.isEmpty(fullname)) {
            Toast.makeText(this, "Please enter text to comment.", Toast.LENGTH_SHORT).show();
        } else {
            Calendar calTemp = Calendar.getInstance();
            SimpleDateFormat tempTime = new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");
            final String currentTimeStamp = tempTime.format(calTemp.getTime());

            Calendar calFordDate = Calendar.getInstance();
            SimpleDateFormat currentDate = new SimpleDateFormat("MMMM dd, yyyy");
            final String saveCurrentDate = currentDate.format(calFordDate.getTime());
            SimpleDateFormat currentTime = new SimpleDateFormat("h:mm a");
            final String saveCurrentTime = currentTime.format(calFordDate.getTime());

            final String commentRandomKey = current_user_id + currentTimeStamp;

            HashMap commentMap = new HashMap();
            commentMap.put("uid", current_user_id);
            commentMap.put("comment", commentText);
            commentMap.put("date", saveCurrentDate);
            commentMap.put("time", saveCurrentTime);
            commentMap.put("timestamp", currentTimeStamp);
            commentMap.put("username", username);
            commentMap.put("fullname", fullname);
            commentMap.put("profileimage", profileimage);

            commentsRef.child(commentRandomKey).updateChildren(commentMap)
                    .addOnCompleteListener(new OnCompleteListener() {
                        @Override
                        public void onComplete(@NonNull Task task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(ClickPostActivity.this, "Comment posted!", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(ClickPostActivity.this, "Error posting comment. Please try again later.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }

    @Override
    public boolean onCreateOptionsMenu (Menu menu) {
        getMenuInflater().inflate(R.menu.post_details_menu, menu);

        if (current_user_id.equals(databaseuserid)) {
            menu.findItem(R.id.edit_post_action).setVisible(true);
            menu.findItem(R.id.delete_post_action).setVisible(true);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            SendToMainActivity();
        }

        switch (id) {
            case android.R.id.home:
                SendToMainActivity();
                break;
            case R.id.report_action:
                Toast.makeText(ClickPostActivity.this, "This post has been reported", Toast.LENGTH_SHORT).show();
                break;
            case R.id.edit_post_action:
                EditCurrentPost(description);
                break;
            case R.id.delete_post_action:
                DeleteCurrentPost();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void EditCurrentPost(String description) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ClickPostActivity.this);
        builder.setTitle("Edit Description");

        final EditText inputField = new EditText(ClickPostActivity.this);
        inputField.setText(description);
        builder.setView(inputField);
        builder.setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                clickPostRef.child("description").setValue(inputField.getText().toString());
                Toast.makeText(ClickPostActivity.this, "Post updated!", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        Dialog dialog = builder.create();
        dialog.show();
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.edit_post_dialog);
    }

    private void DeleteCurrentPost() {

        AlertDialog.Builder deleteBuilder = new AlertDialog.Builder(ClickPostActivity.this);
        deleteBuilder.setTitle("Delete Post");

        deleteBuilder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(ClickPostActivity.this, "Photo Removed", Toast.LENGTH_SHORT).show();
                clickPostRef.removeValue();
                FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
                StorageReference storageReference = firebaseStorage.getReferenceFromUrl(image);
                storageReference.delete();
                SendToMainActivity();
            }
        });

        deleteBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });

        Dialog deleteDialog = deleteBuilder.create();
        deleteDialog.show();
        deleteDialog.getWindow().setBackgroundDrawableResource(R.drawable.edit_post_dialog);

    }

    private void SendToMainActivity() {
        Intent mainIntent = new Intent(ClickPostActivity.this, MainActivity.class);
        startActivity(mainIntent);
    }

}
