package com.cis44140.team3.socialdistance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class AppSettingsActivity extends AppCompatActivity {

    private Button profileSettingsButton;
    private Toolbar mToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_settings);

        mToolbar = findViewById(R.id.toolbar2);
        setSupportActionBar(mToolbar);

        profileSettingsButton = findViewById(R.id.nav_to_profile_settings_button);
        profileSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GoToProfileSettings();
            }
        });

    }

    private void GoToProfileSettings() {
        Intent settingIntent = new Intent(AppSettingsActivity.this, SettingsActivity.class);
        startActivity(settingIntent);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            SendToMainActivity();
        }

        return super.onOptionsItemSelected(item);

    }

    private void SendToMainActivity() {
        Intent mainIntent = new Intent(AppSettingsActivity.this, MainActivity.class);
        startActivity(mainIntent);
    }

}
