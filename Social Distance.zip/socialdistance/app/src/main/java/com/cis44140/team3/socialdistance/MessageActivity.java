package com.cis44140.team3.socialdistance;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class MessageActivity extends AppCompatActivity {

    private Toolbar messageToolbar;
    private ImageButton sendMessage, sendImage;
    private EditText userMessageInput;
    private RecyclerView userMessageList;
    private String messageReciverId, messageRecieverFullName, getMessageReciverUserName, messageText, messageSenderId, messageSenderRef, messageRecieverRef;
    private String messageReciverProfileImageUrl = null;
    private TextView app_bar_layout_title_text;
    private CircleImageView smallProfileImage, message_profie_image;
    private final List<Messages> messagesList = new ArrayList<>();
    private LinearLayoutManager linearLayoutManager;
    private MessagesAdapter messagesAdapter;

    private FirebaseAuth mAuth;
    private DatabaseReference rootRef, NotificationsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        mAuth = FirebaseAuth.getInstance();
        messageSenderId = mAuth.getCurrentUser().getUid();

        rootRef = FirebaseDatabase.getInstance().getReference();
        NotificationsRef = FirebaseDatabase.getInstance().getReference().child("Notifications");

        InitalizeFields();

        userMessageInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE)) {
                    sendMessage.performClick();
                    hideKeyboard(MessageActivity.this);
                }
                return false;
            }
        });

        sendMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SendMessage();
            }
        });

        GetMessages();

    }

    private void GetMessages() {
        rootRef.child("Messages").child(messageSenderId).child(messageReciverId).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                if (dataSnapshot.exists()) {
                    Messages messages = dataSnapshot.getValue(Messages.class);
                    messagesList.add(messages);
                    messagesAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void SendMessage() {
        messageText = userMessageInput.getText().toString();

        if (TextUtils.isEmpty(messageText)) {
            Toast.makeText(this, "Don't forget to type your message!", Toast.LENGTH_SHORT).show();
        } else {
            messageSenderRef = "Messages/" + messageSenderId + "/" + messageReciverId;
            messageRecieverRef = "Messages/" + messageReciverId + "/" + messageSenderId;

            DatabaseReference userMessageReference = rootRef.child("Messages").child(messageSenderId).child(messageReciverId).push();
            String messagePushId = userMessageReference.getKey();

            Calendar calFordDate = Calendar.getInstance();
            SimpleDateFormat currentDate = new SimpleDateFormat("MMMM dd, yyyy");
            final String saveCurrentDate = currentDate.format(calFordDate.getTime());

            SimpleDateFormat currentTime = new SimpleDateFormat("h:mm a");
            final String saveCurrentTime = currentTime.format(calFordDate.getTime());

            Map messageTextBody = new HashMap();
            messageTextBody.put("message", messageText);
            messageTextBody.put("date", saveCurrentDate);
            messageTextBody.put("time", saveCurrentTime);
            messageTextBody.put("type", "text");
            messageTextBody.put("from", messageSenderId);

            Map messageBodyDetails = new HashMap();
            messageBodyDetails.put(messageSenderRef + "/" + messagePushId, messageTextBody);
            messageBodyDetails.put(messageRecieverRef + "/" + messagePushId, messageTextBody);

            rootRef.updateChildren(messageBodyDetails).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(MessageActivity.this, "Message sent", Toast.LENGTH_SHORT).show();
                        userMessageInput.setText("");
                    } else {
                        String message = task.getException().getMessage();
                        Toast.makeText(MessageActivity.this, "Error: " + message, Toast.LENGTH_SHORT).show();
                        userMessageInput.setText("");
                    }

                }
            });

            Map notifcationHashMap = new HashMap();
            notifcationHashMap.put("from", messageSenderId);
            notifcationHashMap.put("type", "message");

            NotificationsRef.child(messageReciverId).push().setValue(notifcationHashMap);

        }

    }

    private void InitalizeFields() {
        messageToolbar = findViewById(R.id.messages_top_bar);
        setSupportActionBar(messageToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);
        sendMessage = findViewById(R.id.sendMessageButton);
        sendImage = findViewById(R.id.sendPhotoButton);
        userMessageInput = findViewById(R.id.messageEditText);
        userMessageList = findViewById(R.id.messagesRecycleView);

        try {
            messageReciverProfileImageUrl = getIntent().getExtras().get("user_profile_image").toString();
        } catch (Exception e) {
        }
        try {
            messageReciverId = getIntent().getExtras().get("visit_user_id").toString();
        } catch (Exception e) {
        }
        try {
            getMessageReciverUserName = getIntent().getExtras().get("user_name").toString();
        } catch (Exception e) {
        }
        try {
            messageRecieverFullName = getIntent().getExtras().get("user_full_name").toString();
        } catch (Exception e) {
        }

        app_bar_layout_title_text = findViewById(R.id.messages_top_app_bar_title);
        app_bar_layout_title_text.setText(messageRecieverFullName);
        smallProfileImage = findViewById(R.id.messages_top_bar_profile_image);
        message_profie_image = findViewById(R.id.message_profie_image);

        String[] tokens =  messageRecieverFullName.split(" ");

        userMessageInput.setHint("Send message to " + tokens[0]);

        Picasso.get().load(messageReciverProfileImageUrl).placeholder(R.drawable.profile).into(smallProfileImage);

        smallProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent profileIntent = new Intent(MessageActivity.this, ViewProfileActivity.class);
                profileIntent.putExtra("visit_user", messageReciverId);
                profileIntent.putExtra("previous_intent", "messages");
                startActivity(profileIntent);
            }
        });

        messagesAdapter = new MessagesAdapter(messagesList);
        linearLayoutManager = new LinearLayoutManager(this);
        userMessageList.setHasFixedSize(true);
        userMessageList.setLayoutManager(linearLayoutManager);
        userMessageList.setAdapter(messagesAdapter);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            SendUserToFriendsPage();
        }
        return super.onOptionsItemSelected(item);
    }

    private void SendUserToFriendsPage() {
        Intent messagesIntent = new Intent(MessageActivity.this, FriendsActivity.class);
        startActivity(messagesIntent);
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

}
