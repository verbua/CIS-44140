package com.cis44140.team3.socialdistance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import de.hdodenhof.circleimageview.CircleImageView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;
import java.util.Objects;

public class SettingsActivity extends AppCompatActivity {

    private Toolbar mToolbar;
    private EditText userName, phoneNumber, birthDate, gender, relationshipStatus, status, fullName;
    private CircleImageView profileImage, reallySmallProfileImage;
    private Button updateAccountButton;

    private DatabaseReference settingsUserRef;
    private FirebaseAuth mAuth;
    private StorageReference UserProfileImageRef;

    private String current_user_id;
    private ProgressDialog loadingBar;
    final static int Gallery_pic = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        reallySmallProfileImage = (CircleImageView) findViewById(R.id.top_bar_profile_image);
        reallySmallProfileImage.setVisibility(View.GONE);

        mAuth = FirebaseAuth.getInstance();
        current_user_id = mAuth.getCurrentUser().getUid();
        settingsUserRef = FirebaseDatabase.getInstance().getReference().child("Users").child(current_user_id);
        UserProfileImageRef = FirebaseStorage.getInstance().getReference().child("profile Images");

        loadingBar = new ProgressDialog(this);

        mToolbar = (Toolbar) findViewById(R.id.top_bar_account_settings);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Profile Settings");
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        Objects.requireNonNull(getSupportActionBar()).setHomeAsUpIndicator(R.drawable.ic_arrow_back_black_24dp);

        userName = (EditText) findViewById(R.id.settings_user_name);
        phoneNumber = (EditText) findViewById(R.id.settings_phone_number);
        birthDate = (EditText) findViewById(R.id.settings_date_of_birth);
        gender = (EditText) findViewById(R.id.settings_gender);
        relationshipStatus = (EditText) findViewById(R.id.settings_relationship_status);
        status= (EditText) findViewById(R.id.settings_user_status);
        fullName = (EditText) findViewById(R.id.settings_full_name);
        profileImage = (CircleImageView) findViewById(R.id.settings_profile_image);
        updateAccountButton = (Button) findViewById(R.id.settings_update_button);

        settingsUserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String profileImageUrl = null;
                    if (dataSnapshot.hasChild("profileimage")) {
                        profileImageUrl = Objects.requireNonNull(dataSnapshot.child("profileimage").getValue()).toString();
                        Picasso.get().load(profileImageUrl).placeholder(R.drawable.profile).into(profileImage);
                    }
                    String username = Objects.requireNonNull(dataSnapshot.child("username").getValue()).toString();
                    username = username.substring(2, username.length());
                    String phoneNo = Objects.requireNonNull(dataSnapshot.child("phonenumber").getValue()).toString();
                    String birthday = Objects.requireNonNull(dataSnapshot.child("dob").getValue()).toString();
                    String genderDesc = Objects.requireNonNull(dataSnapshot.child("gender").getValue()).toString();
                    String relationStatus = Objects.requireNonNull(dataSnapshot.child("relationshipstatus").getValue().toString());
                    String userStatus = Objects.requireNonNull(dataSnapshot.child("status").getValue().toString());
                    String fullCompleteName = Objects.requireNonNull(dataSnapshot.child("fullname").getValue().toString());

                    userName.setText(username);
                    phoneNumber.setText(phoneNo);
                    birthDate.setText(birthday);
                    gender.setText(genderDesc);
                    relationshipStatus.setText(relationStatus);
                    status.setText(userStatus);
                    fullName.setText(fullCompleteName);
                    Picasso.get().load(profileImageUrl).placeholder(R.drawable.profile);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        updateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidateAccountInformation();
            }
        });

        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, Gallery_pic);
            }
        });

    }

    private void ValidateAccountInformation() {
        String username = userName.getText().toString();
        String userStatus = status.getText().toString();
        String dob = birthDate.getText().toString();
        String userGender = gender.getText().toString();
        String userPhoneNumber = phoneNumber.getText().toString();
        String userRelationshipStatus = relationshipStatus.getText().toString();
        String fullname = fullName.getText().toString();


        if (TextUtils.isEmpty(username)) {
            Toast.makeText(SettingsActivity.this, "All fields must have a value", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(userStatus)) {
            Toast.makeText(SettingsActivity.this, "All fields must have a value", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(dob)) {
            Toast.makeText(SettingsActivity.this, "All fields must have a value", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(userGender)) {
            Toast.makeText(SettingsActivity.this, "All fields must have a value", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(userPhoneNumber)) {
            Toast.makeText(SettingsActivity.this, "All fields must have a value", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(userRelationshipStatus)) {
            Toast.makeText(SettingsActivity.this, "All fields must have a value", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(fullname)) {
            Toast.makeText(SettingsActivity.this, "All fields must have a value", Toast.LENGTH_SHORT).show();
        } else {
            loadingBar.setTitle("Updating information");
            loadingBar.setMessage("Please wait");
            loadingBar.setCanceledOnTouchOutside(true);
            loadingBar.show();
            UpdateAccountInformation(username, userStatus, dob, userGender, userPhoneNumber, userRelationshipStatus, fullname);
        }

    }

    private void UpdateAccountInformation(String username, String userStatus, String dob, String userGender, String userPhoneNumber, String userRelationshipStatus, String fullname) {
        HashMap userMap = new HashMap();
        userMap.put("username", "@ " + username);
        userMap.put("status", userStatus);
        userMap.put("gender", userGender);
        userMap.put("dob", dob);
        userMap.put("relationshipstatus", userRelationshipStatus);
        userMap.put("phonenumber", userPhoneNumber);
        userMap.put("fullname", fullname);

        settingsUserRef.updateChildren(userMap).addOnCompleteListener(new OnCompleteListener() {
            @Override
            public void onComplete(@NonNull Task task) {
                if (task.isSuccessful()) {
                    Toast.makeText(SettingsActivity.this, "Account settings updated!", Toast.LENGTH_SHORT).show();
                    loadingBar.dismiss();
                    SendUserToMainActivity();
                } else {
                    Toast.makeText(SettingsActivity.this, "Unsuccessful save", Toast.LENGTH_SHORT).show();
                    loadingBar.dismiss();
                }
            }
        });

    }

    private void SendUserToMainActivity() {
        Intent mainIntent = new Intent(SettingsActivity.this, MainActivity.class);
        startActivity(mainIntent);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            SendUserToMainActivity();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // some conditions for the picture
        if (requestCode == Gallery_pic && resultCode == RESULT_OK && data != null) {
            Uri ImageUri = data.getData();
            // crop the image
            CropImage.activity(ImageUri)
                    .setGuidelines(CropImageView.Guidelines.ON)
                    .setAspectRatio(1, 1)
                    .start(this);
        }
        // Get the cropped image
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {       // store the cropped image into result
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if (resultCode == RESULT_OK) {
                loadingBar.setTitle("Profile Image");
                loadingBar.setMessage("Please wait");
                loadingBar.setCanceledOnTouchOutside(true);
                loadingBar.show();

                Uri resultUri = result.getUri();

                final StorageReference filePath = UserProfileImageRef.child(current_user_id + ".jpg");

                filePath.putFile(resultUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        filePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                final String downloadUrl = uri.toString();
                                settingsUserRef.child("profileimage").setValue(downloadUrl).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {

                                            Intent selfIntent = new Intent(SettingsActivity.this, SettingsActivity.class);
                                            startActivity(selfIntent);
                                            Toast.makeText(SettingsActivity.this, "Image saved", Toast.LENGTH_SHORT).show();
                                            loadingBar.dismiss();
                                        } else {
                                            String message = task.getException().getMessage();
                                            Toast.makeText(SettingsActivity.this, "Error:" + message, Toast.LENGTH_SHORT).show();
                                            loadingBar.dismiss();
                                        }
                                    }
                                });
                            }

                        });

                    }

                });
            } else {
                Toast.makeText(this, "Error Occured: Image can not be cropped. Try Again.", Toast.LENGTH_SHORT).show();
                loadingBar.dismiss();
            }
        }
    }

}
