package com.example.gpacalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner grade1 = findViewById(R.id.grade1);
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.gradeArray, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        grade1.setPrompt("Grade");
        grade1.setAdapter(adapter1);

        Spinner grade2 = findViewById(R.id.grade2);
        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.gradeArray, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        grade2.setPrompt("Grade");
        grade2.setAdapter(adapter2);

        Spinner grade3 = findViewById(R.id.grade3);
        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.gradeArray, android.R.layout.simple_spinner_item);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        grade3.setPrompt("Grade");
        grade3.setAdapter(adapter3);

        Spinner grade4 = findViewById(R.id.grade4);
        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this, R.array.gradeArray, android.R.layout.simple_spinner_item);
        adapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        grade4.setPrompt("Grade");
        grade4.setAdapter(adapter4);

        Spinner grade5 = findViewById(R.id.grade5);
        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this, R.array.gradeArray, android.R.layout.simple_spinner_item);
        adapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        grade5.setPrompt("Grade");
        grade5.setAdapter(adapter5);

        Spinner grade6 = findViewById(R.id.grade6);
        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this, R.array.gradeArray, android.R.layout.simple_spinner_item);
        adapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        grade6.setPrompt("Grade");
        grade6.setAdapter(adapter6);

        Spinner points1 = findViewById(R.id.pointsTwo);
        ArrayAdapter<CharSequence> arrAdapter1 = ArrayAdapter.createFromResource(this, R.array.numberArray, android.R.layout.simple_spinner_item);
        arrAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        points1.setAdapter(arrAdapter1);

        Spinner points2 = findViewById(R.id.pointsThree);
        ArrayAdapter<CharSequence> arrAdapter2 = ArrayAdapter.createFromResource(this, R.array.numberArray, android.R.layout.simple_spinner_item);
        arrAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        points2.setAdapter(arrAdapter2);

        Spinner points3 = findViewById(R.id.pointsFour);
        ArrayAdapter<CharSequence> arrAdapter3 = ArrayAdapter.createFromResource(this, R.array.numberArray, android.R.layout.simple_spinner_item);
        arrAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        points3.setAdapter(arrAdapter3);

        Spinner points4 = findViewById(R.id.pointsFive);
        ArrayAdapter<CharSequence> arrAdapter4 = ArrayAdapter.createFromResource(this, R.array.numberArray, android.R.layout.simple_spinner_item);
        arrAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        points4.setAdapter(arrAdapter4);

        Spinner points5 = findViewById(R.id.pointsOne);
        ArrayAdapter<CharSequence> arrAdapter5 = ArrayAdapter.createFromResource(this, R.array.numberArray, android.R.layout.simple_spinner_item);
        arrAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        points5.setAdapter(arrAdapter5);

        Spinner points6 = findViewById(R.id.pointsSix);
        ArrayAdapter<CharSequence> arrAdapter6 = ArrayAdapter.createFromResource(this, R.array.numberArray, android.R.layout.simple_spinner_item);
        arrAdapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        points6.setAdapter(arrAdapter6);



    }

    public double getCoursePoints (String grade) {
        double coursePoints = 0.0;

        switch (grade) {
            case "A":
                coursePoints = 4.0;
                break;
            case "A-":
                coursePoints = 3.7;
                break;
            case "B+":
                coursePoints += 3.33;
                break;
            case "B":
                coursePoints = 3.0;
                break;
            case "B-":
                coursePoints = 2.7;
                break;
            case "C+":
                coursePoints = 2.3;
                break;
            case "C":
                coursePoints = 2.0;
                break;
            case "C-":
                coursePoints = 1.7;
                break;
            case "D+":
                coursePoints = 1.3;
                break;
            case "D":
                coursePoints = 1.0;
                break;
            case "F":
                coursePoints = 0.0;
                break;
        }

        return coursePoints;
    }

    @SuppressLint("SetTextI18n")
    public void calculateGPA(View view) {
        double GPA = 0.0;
        double hours = 0.0;
        double points = 0.0;

        boolean valid= true;

        String response = "N/A";

        DecimalFormat df = new DecimalFormat("0.00");

        TextView gpa = (TextView) findViewById(R.id.GPA);

        Spinner spinner1 = (Spinner) findViewById(R.id.grade1);
        String grade1 = spinner1.getSelectedItem().toString();
        Spinner spinner2 = (Spinner) findViewById(R.id.grade2);
        String grade2 = spinner2.getSelectedItem().toString();
        Spinner spinner3 = (Spinner) findViewById(R.id.grade3);
        String grade3 = spinner3.getSelectedItem().toString();
        Spinner spinner4 = (Spinner) findViewById(R.id.grade4);
        String grade4 = spinner4.getSelectedItem().toString();
        Spinner spinner5 = (Spinner) findViewById(R.id.grade5);
        String grade5 = spinner5.getSelectedItem().toString();
        Spinner spinner6 = (Spinner) findViewById(R.id.grade6);
        String grade6 = spinner6.getSelectedItem().toString();

        Spinner spinner7 = (Spinner) findViewById(R.id.pointsOne);
        String points1 = spinner7.getSelectedItem().toString();
        Spinner spinner8 = (Spinner) findViewById(R.id.pointsTwo);
        String points2 = spinner8.getSelectedItem().toString();
        Spinner spinner9 = (Spinner) findViewById(R.id.pointsThree);
        String points3 = spinner9.getSelectedItem().toString();
        Spinner spinner10 = (Spinner) findViewById(R.id.pointsFour);
        String points4 = spinner10.getSelectedItem().toString();
        Spinner spinner11 = (Spinner) findViewById(R.id.pointsFive);
        String points5 = spinner11.getSelectedItem().toString();
        Spinner spinner12 = (Spinner) findViewById(R.id.pointsSix);
        String points6 = spinner12.getSelectedItem().toString();

        if ((!grade1.equals("")) && (!points1.equals(""))) {
            hours += Double.parseDouble(points1);
            points += Double.parseDouble(points1) * getCoursePoints(grade1);
        }
        if ((!grade2.equals("")) && (!points2.equals(""))) {
            hours += Double.parseDouble(points2);
            points += Double.parseDouble(points2) * getCoursePoints(grade2);
        }
        if((!grade3.equals("")) && (!points3.equals(""))) {
            hours += Double.parseDouble(points3);
            points += Double.parseDouble(points3) * getCoursePoints(grade3);
        }
        if((!grade4.equals("")) && (!points4.equals(""))) {
            hours += Double.parseDouble(points4);
            points += Double.parseDouble(points4) * getCoursePoints(grade4);
        }
        if((!grade5.equals("")) && (!points5.equals(""))) {
            hours += Double.parseDouble(points5);
            points += Double.parseDouble(points5) * getCoursePoints(grade5);
        }
        if((!grade6.equals("")) && (!points6.equals(""))) {
            hours += Double.parseDouble(points6);
            points += Double.parseDouble(points6) * getCoursePoints(grade6);
        }

        if (valid) {
            GPA = points / hours;
            GPA = Double.parseDouble(df.format(GPA));
        }
        if (GPA != 0.0) {
            gpa.setText(Double.toString(GPA));
        } else {
            gpa.setText(response);
        }

    }
}
